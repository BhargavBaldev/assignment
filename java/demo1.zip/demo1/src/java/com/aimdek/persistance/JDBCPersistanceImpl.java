/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aimdek.persistance;
import com.aimdek.model.*;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author Bhargav Baldev
 */
public class JDBCPersistanceImpl implements JDBCPersistance{

    @Override
    public boolean update(JDBCModel e) {
       try {
        Connection con=JDBCSingleton.getConnection();
	PreparedStatement stmt=con.prepareStatement("UPDATE login SET firstName=?,lastName=?,password=? where id=?"); 
	stmt.setInt(4,e.getId());
        stmt.setString(1,e.getFirstName());
        stmt.setString(2,e.getLastName());
        stmt.setString(3,e.getPassword());
        int i = stmt.executeUpdate();
        if(i>=0){
        return true;
        }
        return false;
	} catch (SQLException E) {
	E.printStackTrace();
	return false;
	}
    }

    @Override
    public boolean delete(JDBCModel e) {
        try {Connection con=JDBCSingleton.getConnection();
			PreparedStatement stmt=con.prepareStatement("DELETE FROM login WHERE firstName=?");
                        stmt.setString(1,e.getFirstName());
			int i = stmt.executeUpdate();
                        if(i>=0){
                        return true;
                        }
                        return false;
		} catch (SQLException E) {
			E.printStackTrace();
			return false;
		}
    }

    @Override
    public boolean insert(JDBCModel e) {
        try {Connection con=JDBCSingleton.getConnection();
			PreparedStatement stmt=con.prepareStatement("INSERT INTO login (firstName,lastName,password) VALUES (?,?,?)");
		
                        stmt.setString(1,e.getFirstName());
			stmt.setString(2,e.getLastName());
			stmt.setString(3,e.getPassword());
			
			int i=stmt.executeUpdate();
			if(i>=0)
			{
				return true;
			}
			return false;
		} catch (SQLException f) {
			f.printStackTrace();
			return false;
		}
    }

    @Override
    public ArrayList<String> read(JDBCModel e) {
        ArrayList<String> data = new ArrayList<String>();
    try {Connection con=JDBCSingleton.getConnection();
			Statement stmt=con.createStatement(); 
			ResultSet rs = stmt.executeQuery("SELECT * FROM login");
                        while(rs.next()){
                           data.add( rs.getString(2));
                           data.add(rs.getString(3));
                           data.add(rs.getString(4));
                        }
                        
		} catch (SQLException E) {
			E.printStackTrace();
                        
		}
    return data;
    }
    
}
