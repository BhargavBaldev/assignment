package com.aimdek.persistance;

import com.aimdek.model.RegModel;
import java.sql.*;
import java.util.*;




public class RegDAO {

	public void insert(RegModel m) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost/bhargav", "root", "root");
			Statement s = c.createStatement();
			s.executeUpdate("insert into student(fn,ln) values('" + m.getFn() + "','" + m.getLn() + "')");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List search() {
		List ls = new ArrayList<>();
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/bhargav", "root", "root");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery("select * from student");

			while (rs.next()) {
				RegModel m = new RegModel();
				m.setId(rs.getInt("id"));
				m.setFn(rs.getString("fn"));
				m.setLn(rs.getString("ln"));

				ls.add(m);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ls;
	}

	public void delete(RegModel m) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost/bhargav", "root", "root");
			Statement s = c.createStatement();
			s.executeUpdate("delete from student where id='" + m.getId() + "'");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List edit(RegModel m) {
		List editlist = new ArrayList();
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost/bhargav", "root", "root");
			Statement s = c.createStatement();

			ResultSet rs = s.executeQuery("select * from student where id='" + m.getId() + "'");

			while (rs.next()) {
				RegModel m1 = new RegModel();
				m1.setId(rs.getInt("id"));
				m1.setFn(rs.getString("fn"));
				m1.setLn(rs.getString("ln"));

				editlist.add(m1);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return editlist;

	}

	public void update(RegModel m) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost/bhargav", "root", "root");
			Statement s = c.createStatement();
			s.executeUpdate("update student set fn='" + m.getFn() + "',ln='" + m.getLn() + "' where id='" + m.getId() + "'");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	

}
