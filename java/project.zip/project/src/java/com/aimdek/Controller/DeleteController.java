
package com.aimdek.Controller;

import com.aimdek.model.RegModel;
import com.aimdek.persistance.RegDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DeleteController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RegDAO regdao=new RegDAO();
        int id=Integer.parseInt(request.getParameter("id"));
			RegModel m=new RegModel();
			m.setId(id);
			regdao.delete(m);
			
			response.sendRedirect("SearchController");
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    
}
