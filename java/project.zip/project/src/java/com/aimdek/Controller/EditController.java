
package com.aimdek.Controller;


import com.aimdek.model.RegModel;
import com.aimdek.persistance.RegDAO;
import java.io.IOException;

import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EditController extends HttpServlet {

   

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RegDAO regdao=new RegDAO();
        int id=Integer.parseInt(request.getParameter("id"));
			RegModel m=new RegModel();
			m.setId(id);
			
			List ls=regdao.edit(m);
			
			
			request.setAttribute("data",ls);
			
			request.getRequestDispatcher("/edit.jsp").forward(request,
          response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

   
    
}
